

const express=require('express');
var cors = require('cors')
var request = require('request');





//set up express 
const app =express();
app.use(cors())
console.log("idex js is called ");

var request = require('request');

		

        app.get('/getServerDetails',(req,res)=>{
            request
            .get({
                url: 'https://psm-naresco.console.oraclecloud.com/paas/api/v1.1/instancemgmt/idcs-f8389d83d38d4d319969bd57a82e61bc/services/jaas/instances/NCLJCSTST',
                headers: {
                    Authorization: "Basic b3JhY2xlYmFja3VwQG5hcmVzY28uYWU6TmFyZTUwNGlwQWFz"
                }
            },
         
                function (error, response, body) {
                    console.log('error:', error); // Print the error if one occurred
                    console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
                    console.log('body:', body); // Print the HTML for the Google homepage.
                    res.send(body);
        
                });
          
            
            
            })
//listing for request
app.listen(9001,()=>{

    console.log("waiting for the request");
    });